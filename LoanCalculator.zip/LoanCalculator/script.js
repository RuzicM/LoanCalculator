//Get element
document.getElementById('loan-form').addEventListener('submit', function(e){
    //Hide Results
    document.querySelector('#results').style.display = 'none';
    //Show Loader
    document.querySelector('#loading').style.display = 'block';
    setTimeout(calculateResults, 2000);
    e.preventDefault();

});

function calculateResults(e){

    //UI variables
    const amount = document.querySelector('#amount');
    const intrest = document.querySelector('#intrest');
    const years = document.querySelector('#years');
    const monthlyPayment = document.querySelector('#monthly-payment');
    const totalPayment = document.querySelector('#total-payment');
    const totalIntrest = document.querySelector('#total-intrest');
    
    const principal = parseFloat(amount.value);
    const calculateIntrest = parseFloat(intrest.value) / 100 /12;
    const calculatePayments = parseFloat(years.value) * 12;
    
    const x = Math.pow(1 + calculateIntrest, calculatePayments);
    const monthly = (principal * x * calculateIntrest) / (x - 1);
    
    if(isFinite(monthly)) {
        monthlyPayment.value = monthly.toFixed(2);
        totalPayment.value = (monthly * calculatePayments).toFixed(2);
        totalIntrest.value = ((monthly * calculatePayments) - principal).toFixed(2);
        //Show result and hide loading img
        document.querySelector('#results').style.display = 'block';
        document.querySelector('#loading').style.display = 'none';
    }else {
        showError('Please chekc your numbers');
        document.querySelector('#loading').style.display = 'none';
    }



}

function showError(error){
    //Create div element
    const errDiv = document.createElement('div');
    
    //Get elements
    const card = document.querySelector('.card');
    const heading = document.querySelector('.heading');

    
    //Add class
    errDiv.className = 'alert alert-danger';
    
    //Create text node and append to div
    errDiv.appendChild(document.createTextNode(error));
    
    //Insert error above heading
    card.insertBefore(errDiv, heading);

    //Clear error 3 sec
    setTimeout(clearError, 3000);
}

//Clear error
function clearError(){
    document.querySelector('.alert').remove();
}